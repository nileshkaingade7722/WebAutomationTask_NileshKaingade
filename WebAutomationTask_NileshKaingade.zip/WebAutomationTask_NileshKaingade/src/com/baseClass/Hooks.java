package com.baseClass;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {

	WebDriver driver;
	
	@Before()
	public void beforeScenario() {
		//Actions action = new Actions(driver);
		//action.launcBrowser();
	}

	@Before()
	public void beforeScenarioStart() {
		
	}
}
