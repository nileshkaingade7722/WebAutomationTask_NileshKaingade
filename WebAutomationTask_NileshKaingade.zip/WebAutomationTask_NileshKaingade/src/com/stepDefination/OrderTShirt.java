package com.stepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.OrderTShirtPage;
import com.pages.PersonalInformationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OrderTShirt {

	WebDriver driver;

	@Given("^I am a valid user and navigate to the site$")
	public void i_am_a_valid_user_and_navigate_to_the_site() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\ChromeDriverEXE\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php?id_category=5&controller=category");
	}

	@Then("^I should see my store page$")
	public void i_should_see_my_store_page() {
		// action = new Actions();
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyStorePage();
	}

	@When("^I select tshirt categories from top menu$")
	public void i_select_tshirt_categories_from_top_menu() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.clickTShirtTab();
		orderTShirtPage.scrollElement();
	}

	@Then("^I should see the product list on tshirt page$")
	public void i_should_see_the_product_list_on_tshirt_page()
			throws InterruptedException {
		Thread.sleep(5000);
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.productListPage();
		Thread.sleep(5000);
	}

	@Then("^I select the Add to cart button$")
	public void i_select_the_Add_to_cart_button() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.addToCart();
	}

	@Then("^I verify selected product item is successfully added to shopping cart$")
	public void i_verify_selected_product_item_is_successfully_added_to_shopping_cart() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.productSuccessFullyPage();
	}

	@Then("^I select Proceed to checkout button on item in your cart screen$")
	public void i_select_Proceed_to_checkout_button_on_item_in_your_cart_screen()
			throws InterruptedException {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		Thread.sleep(5000);
		orderTShirtPage.proceedToCheckout();
		orderTShirtPage.scrollElement();
		orderTShirtPage.shopingCartProceedToCheckout();
	}

	@Then("^I should be on autentication page$")
	public void i_should_be_on_autentication_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.autenticationPage();
	}

	@Then("^I enter my login (.*) and (.*) to autenticate successfully$")
	public void i_enter_my_login_and_to_autenticate_successfully(
			String EmailAddress, String Password) {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		EmailAddress = "nilesh.kaingade@gmail.com";
		Password = "Test123";
		orderTShirtPage.loginDetails(EmailAddress, Password);
	}

	@Then("^I select Proceed to checkout button on address page$")
	public void i_select_Proceed_to_checkout_button_on_address_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.scrollElement();
		orderTShirtPage.clickAddressProceedToCheckoutButton();
	}

	@Then("^I should be on address page$")
	public void i_should_be_on_address_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyAddressPage();
	}

	@Then("^I should be on shipping page$")
	public void i_should_be_on_shipping_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyShippingPage();
	}

	@Then("^select Terms of service chec kbox button$")
	public void select_Terms_of_service_chec_kbox_button() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.TermOfService();
	}

	@Then("^I select Proceed to checkout button on shipping page$")
	public void i_select_Proceed_to_checkout_button_on_shipping_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.clickShippingProceedToCheckoutButton();
	}

	@Then("^I should be on payment method page$")
	public void i_should_be_on_payment_method_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyPaymentMethodPage();
	}

	@Then("^I select (.*) on choose your payment method page$")
	public void i_select_on_choose_your_payment_method_page(String paymentMetod) {
		paymentMetod = "Pay by bank wire";
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		if (paymentMetod.equalsIgnoreCase("Pay by bank wire")) {
			orderTShirtPage.clickPayByBankWireMethod();
		} else {
			orderTShirtPage.clickPayByBankChequeMethod();
		}
	}
	
	@Then("^I should be on order summary page$")
	public void i_should_be_on_order_summary_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyOrderSummaryPage();
	}
	
	@Then("^I select confirm my order$")
	public void i_select_confirm_my_order() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.selectOrderConfirmButton();
	}
	
	@Then("^I should be on order confirmation page$")
	public void i_should_be_on_order_confirmation_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.OrderConfirmationPage();
	}

	@Then("^I should verify the (.*) of product$")
	public void i_should_verify_the_of_product(String amount) {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.verifyOrderAmount();
		orderTShirtPage.getOrderReference();
	}
	
	
	@Then("^I select my account to view my order history$")
	public void i_select_my_account_to_view_my_order_history() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.selectViewCustomerAccount();
	}

	@Then("^I should be on my account page$")
	public void i_should_be_on_my_account_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.MyAccountPage();
	}

	@Then("^I select order history and details option$")
	public void i_select_order_history_and_details_option() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.selectOrderhistoryDetails();
	}

	@Then("^I should be on Order history page$")
	public void i_should_be_on_Order_history_page() {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.VerifyorderhistoryPage();
	}

	@Then("^I should verify the (.*) and (.*) details$")
	public void i_should_verify_the_and_details(String arg1, String arg2) {
		OrderTShirtPage orderTShirtPage = new com.pages.OrderTShirtPage(driver);
		orderTShirtPage.OrderReferenceNumber();
		orderTShirtPage.TotalPrice();
	}
	
	@Then("^I select my personal information option$")
	public void i_select_my_personal_information_option() {
		OrderTShirt OrderTShirt = new OrderTShirt();
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver);
		personalInformationPage.selectPersonalInformation();
	}
	
	@When("^I select sign in link to Log in to your my account$")
	public void i_select_sign_in_link_to_Log_in_to_your_my_account() {
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver);
		personalInformationPage.LoginLink();
	}

	@Then("^I should be on Your personal information page$")
	public void i_should_be_on_Your_personal_information_page() {
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver);
		personalInformationPage.verifYourPersonalInformationPage();
	}

	@Then("^update my (.*) details$")
	public void update_my_details(String arg1) throws InterruptedException {
		PersonalInformationPage personalInformationPage = new PersonalInformationPage(driver);
		personalInformationPage.firstName();
		personalInformationPage.enterPassword();
		personalInformationPage.selectSaveButton();
		personalInformationPage.verifyupdaeDetailsSaveSuccessfully();
	}
}
