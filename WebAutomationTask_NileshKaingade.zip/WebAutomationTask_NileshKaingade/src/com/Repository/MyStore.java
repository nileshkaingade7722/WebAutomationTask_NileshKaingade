package com.Repository;

public interface MyStore {

	String TShirtTab="//li[@class='sfHoverForce']/a";  //a[contains(.,'T-shirts')]
	String ProductContainer="//div[@class='product-image-container']/a";
	//String AddToCart="//button[@name='Submit']";
	String AddToCart="//a[@class='button ajax_add_to_cart_button btn btn-default']";
	String ProceedToCheckout="//a[@class='btn btn-default button button-medium']";
	String ShopingCartProceedToCheckout="//a[@class='button btn btn-default standard-checkout button-medium']";
	//a[@class='button btn btn-default standard-checkout button-medium']
	String ViewMyShoppingCart="//a[@title='View my shopping cart']";
	String CheckOutButton="//a[@id='button_order_cart']";
	String ProductSuccessfulyTitle="//h2[contains(.,'Product successfully added to your shopping cart')]";
	String EmailAddress="//input[@id='email']";
	String SignPassword="//input[@id='passwd']";
	String LoginButton="//button[@id='SubmitLogin']";
	String AddressProceedToCheckout="//button[@name='processAddress']";
	String AddressPage ="//h1[contains(.,'Addresses')]";
	String ShippingPage ="//h1[contains(.,'Shipping')]";
	String TermOfService ="//input[@id='cgv']";
	String ShippingProceedToCheckoutButton="//button[@name='processCarrier']";
	String PayByBankWireMethod ="//a[@class='bankwire']";
	String PayByBankChequeMethod ="//a[@class='cheque']";
	String PaymentMethodPage ="//h1[contains(.,'Please choose your payment method')]";
	String OrderSummaryPage ="//h1[contains(.,'Order summary')]";
	String OrderConfirmButton ="//button[@class='button btn btn-default button-medium']";
	String OrderConfirmationPage ="//h1[contains(.,'Order confirmation')]";
	String Amount ="//span[@class='price']/strong";
	String OrderReferenceDetails ="//div[@class='box']/br";
	String ViewCustomerAccount ="//a[@class='account']";
	String MyAccountPage ="//h1[contains(.,'My account')]";
	String OrderhistoryDetails ="//ul[@class='myaccount-link-list']/li/a";
	String OrderhistoryPage ="//h1[contains(.,'Order history')]";
	String OrderReferenceNumber ="//table[@id='order-list']/tbody/tr/td/a";
	String TotalPrice ="//table[@id='order-list']/tbody/tr/td[3]/span";
	String MyPersonalInformation ="//span[contains(.,'My personal information')]";
	String YourPersonalInformation ="//h1[contains(.,'Your personal information')]";
	String FirstName ="//input[@id='firstname']";
	String SaveButton="//button[@name='submitIdentity']";
	String UpdaeDetailsSaveSuccessfully="//p[@class='alert alert-success']";
	String PasswordTextBox ="//input[@id='old_passwd']";
	String LoginLink ="//a[@class='login']";
}
