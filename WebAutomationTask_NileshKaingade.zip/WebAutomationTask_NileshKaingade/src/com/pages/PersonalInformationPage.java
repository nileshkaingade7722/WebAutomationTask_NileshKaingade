package com.pages;

import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.Repository.MyStore;

public class PersonalInformationPage implements MyStore{

	WebDriver driver;
	public String verifyAmount;
	public String orderReference;
	public String verifyExpectedRefernece;
	public String verifyExpectedTotalPrice;

	public PersonalInformationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = MyPersonalInformation)
	WebElement myPersonalInformation;
	
	@FindBy(how = How.XPATH, using = YourPersonalInformation)
	WebElement yourPersonalInformation;
	
	@FindBy(how = How.XPATH, using = FirstName)
	WebElement firstName;
	
	@FindBy(how = How.XPATH, using = PasswordTextBox)
	WebElement passwordTextBox;
	
	@FindBy(how = How.XPATH, using = UpdaeDetailsSaveSuccessfully)
	WebElement updaeDetailsSaveSuccessfully;
	
	@FindBy(how = How.XPATH, using = SaveButton)
	WebElement saveButton;
	
	@FindBy(how = How.XPATH, using = LoginLink)
	WebElement loginLink;
	
	public void selectPersonalInformation() {
		myPersonalInformation.click();
	}
	
	public void verifYourPersonalInformationPage() {
		yourPersonalInformation.isDisplayed();
	}
	
	public void verifyupdaeDetailsSaveSuccessfully() {
		String ActualMessage = updaeDetailsSaveSuccessfully.getText();
		Assert.assertEquals("Your personal information has been successfully updated.", ActualMessage);
	}
	
	public void enterPassword() {
		passwordTextBox.sendKeys("Test123");
	}
	
	public void firstName() {
		firstName.sendKeys("EditName");
	}
	
	public void selectSaveButton() {
		saveButton.click();
	}
	
	public void LoginLink() {
		loginLink.click();
	}
}
