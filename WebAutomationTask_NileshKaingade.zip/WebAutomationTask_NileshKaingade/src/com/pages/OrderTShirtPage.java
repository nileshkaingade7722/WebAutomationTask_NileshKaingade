package com.pages;

import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.Repository.MyStore;

public class OrderTShirtPage implements MyStore {

	WebDriver driver;
	public String verifyAmount;
	public String orderReference;
	public String verifyExpectedRefernece;
	public String verifyExpectedTotalPrice;

	public OrderTShirtPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.XPATH, using = TShirtTab)
	List<WebElement> tShirtTab;

	@FindBy(how = How.XPATH, using = ProductContainer)
	WebElement productContainer;

	@FindBy(how = How.XPATH, using = AddToCart)
	WebElement addToCart;

	@FindBy(how = How.XPATH, using = ProceedToCheckout)
	WebElement proceedToCheckout;

	@FindBy(how = How.XPATH, using = ViewMyShoppingCart)
	WebElement viewMyShoppingCart;

	@FindBy(how = How.XPATH, using = CheckOutButton)
	WebElement checkOutButton;

	@FindBy(how = How.XPATH, using = ProductSuccessfulyTitle)
	WebElement productSuccessfulyTitle;

	@FindBy(how = How.XPATH, using = ShopingCartProceedToCheckout)
	WebElement shopingCartProceedToCheckout;

	@FindBy(how = How.XPATH, using = EmailAddress)
	WebElement emailAddress;

	@FindBy(how = How.XPATH, using = SignPassword)
	WebElement signPassword;

	@FindBy(how = How.XPATH, using = LoginButton)
	WebElement loginButton;

	@FindBy(how = How.XPATH, using = AddressProceedToCheckout)
	WebElement addressProceedToCheckout;

	@FindBy(how = How.XPATH, using = AddressPage)
	WebElement addressPage;

	@FindBy(how = How.XPATH, using = ShippingPage)
	WebElement shippingPage;

	@FindBy(how = How.XPATH, using = TermOfService)
	WebElement termOfService;

	@FindBy(how = How.XPATH, using = ShippingProceedToCheckoutButton)
	WebElement shippingProceedToCheckoutButton;

	@FindBy(how = How.XPATH, using = PaymentMethodPage)
	WebElement paymentMethodPage;

	@FindBy(how = How.XPATH, using = PayByBankWireMethod)
	WebElement payByBankWireMethod;

	@FindBy(how = How.XPATH, using = PayByBankChequeMethod)
	WebElement payByBankChequeMethod;

	@FindBy(how = How.XPATH, using = OrderSummaryPage)
	WebElement orderSummaryPage;

	@FindBy(how = How.XPATH, using = OrderConfirmButton)
	WebElement orderConfirmButton;

	@FindBy(how = How.XPATH, using = OrderConfirmationPage)
	WebElement orderConfirmationPage;

	@FindBy(how = How.XPATH, using = Amount)
	WebElement amount;
	
	@FindBy(how = How.XPATH, using = OrderReferenceDetails)
	List<WebElement> orderReferenceDetails;
	
	@FindBy(how = How.XPATH, using = MyAccountPage)
	WebElement myAccountPage;
	
	@FindBy(how = How.XPATH, using = OrderhistoryDetails)
	List<WebElement> orderhistoryDetails;
	
	@FindBy(how = How.XPATH, using = ViewCustomerAccount)
	WebElement viewCustomerAccount;
	
	@FindBy(how = How.XPATH, using = OrderhistoryPage)
	WebElement orderhistoryPage;
	
	@FindBy(how = How.XPATH, using = OrderReferenceNumber)
	WebElement orderReferenceNumber;
	
	@FindBy(how = How.XPATH, using = TotalPrice)
	WebElement totalPrice;
	
	public void clickTShirtTab() {
		tShirtTab.get(1).click();
	}

	public void clickProductContainer() {
		productContainer.click();
	}

	public void addToCart() {
		addToCart.click();
	}

	public void proceedToCheckout() {
		proceedToCheckout.click();
	}

	public void viewMyShoppingCart() {
		viewMyShoppingCart.click();
	}

	public void checkOutButton() {
		checkOutButton.click();
	}

	public void verifyStorePage() {
		tShirtTab.get(1).isDisplayed();
	}

	public void scrollElement() {
		JavascriptExecutor js = (JavascriptExecutor) this.driver;
		js.executeScript("window.scrollBy(0,700)", "");
	}

	public void productListPage() {
		productContainer.isDisplayed();
		// productContainer.click();
		org.openqa.selenium.interactions.Actions action = new org.openqa.selenium.interactions.Actions(
				driver);
		action.moveToElement(productContainer).build().perform();
	}

	public void switchFrame() {
		driver.switchTo().frame("//iframe[@class='fancybox-iframe']");
	}

	public void productSuccessFullyPage() {
		productSuccessfulyTitle.isDisplayed();
	}

	public void shopingCartProceedToCheckout() {
		shopingCartProceedToCheckout.click();
	}

	public void loginDetails(String EmailAddress, String Password) {
		emailAddress.sendKeys(EmailAddress);
		signPassword.sendKeys(Password);
		loginButton.click();
	}

	public void autenticationPage() {
		emailAddress.isDisplayed();
	}

	public void clickAddressProceedToCheckoutButton() {
		addressProceedToCheckout.click();
	}

	public void verifyAddressPage() {
		addressPage.isDisplayed();
	}

	public void verifyShippingPage() {
		shippingPage.isDisplayed();
	}

	public void TermOfService() {
		termOfService.click();
	}

	public void clickShippingProceedToCheckoutButton() {
		shippingProceedToCheckoutButton.click();
	}

	public void verifyPaymentMethodPage() {
		paymentMethodPage.isDisplayed();
	}

	public void clickPayByBankWireMethod() {
		payByBankWireMethod.click();
	}

	public void clickPayByBankChequeMethod() {
		payByBankChequeMethod.click();
	}

	public void verifyOrderSummaryPage() {
		orderSummaryPage.isDisplayed();
	}

	public void selectOrderConfirmButton() {
		orderConfirmButton.click();
	}

	public void OrderConfirmationPage() {
		orderConfirmationPage.isDisplayed();
	}

	public void verifyOrderAmount() {
		verifyAmount = amount.getText();
		System.out.println("=======++++++++++++========" + verifyAmount);
	}
	
	public void getOrderReference() {
		orderReference = orderReferenceDetails.get(5).getText();
		System.out.println("=======++++++++++++========" + orderReference);
	}
	
	public void selectViewCustomerAccount() {
		viewCustomerAccount.click();
	}
	
	public void MyAccountPage() {
		myAccountPage.isDisplayed();
	}
	
	public void selectOrderhistoryDetails() {
		orderhistoryDetails.get(0).click();
	}
	
	public void VerifyorderhistoryPage() {
		orderhistoryPage.isDisplayed();
	}
	
	public void OrderReferenceNumber() {
		verifyExpectedRefernece = orderReferenceNumber.getText();
		Assert.assertEquals(verifyExpectedRefernece, verifyAmount);
	}
	
	public void TotalPrice() {
		verifyExpectedTotalPrice = totalPrice.getText();
		Assert.assertEquals(verifyExpectedTotalPrice, verifyAmount);
	}
}
