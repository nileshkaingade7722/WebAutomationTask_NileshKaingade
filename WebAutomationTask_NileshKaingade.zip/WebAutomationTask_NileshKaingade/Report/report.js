$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature/OrderTShirt.feature");
formatter.feature({
  "name": "Make Order",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Order T-Shirt \u0026 verify in orderdetails",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@Regression"
    }
  ]
});
formatter.step({
  "name": "I am a valid user and navigate to the site",
  "keyword": "Given "
});
formatter.match({
  "location": "OrderTShirt.i_am_a_valid_user_and_navigate_to_the_site()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see my store page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_see_my_store_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select tshirt categories from top menu",
  "keyword": "When "
});
formatter.match({
  "location": "OrderTShirt.i_select_tshirt_categories_from_top_menu()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the product list on tshirt page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_see_the_product_list_on_tshirt_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select the Add to cart button",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_the_Add_to_cart_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I verify selected product item is successfully added to shopping cart",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_verify_selected_product_item_is_successfully_added_to_shopping_cart()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select Proceed to checkout button on item in your cart screen",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_Proceed_to_checkout_button_on_item_in_your_cart_screen()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on autentication page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_autentication_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter my login \u003cEmailAddress\u003e and \u003cPassword\u003e to autenticate successfully",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_enter_my_login_and_to_autenticate_successfully(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on address page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_address_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select Proceed to checkout button on address page",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_Proceed_to_checkout_button_on_address_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on shipping page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_shipping_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "select Terms of service chec kbox button",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.select_Terms_of_service_chec_kbox_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select Proceed to checkout button on shipping page",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_Proceed_to_checkout_button_on_shipping_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on payment method page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_payment_method_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select \u003cpaymentmethod\u003e on choose your payment method page",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_on_choose_your_payment_method_page(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on order summary page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_order_summary_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select confirm my order",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_confirm_my_order()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on order confirmation page",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_order_confirmation_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should verify the \u003cAmount\u003e of product",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_verify_the_of_product(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select my account to view my order history",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_my_account_to_view_my_order_history()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on my account page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_my_account_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select order history and details option",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_order_history_and_details_option()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on Order history page",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_Order_history_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should verify the \u003cOrderReference\u003e and \u003cTotalPrice\u003e details",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_verify_the_and_details(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.uri("Feature/UpdatePersonelInfoDetails.feature");
formatter.feature({
  "name": "Personel Information Details",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Update Personel Information Details(First Name) my Account",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@Regression"
    }
  ]
});
formatter.step({
  "name": "I am a valid user and navigate to the site",
  "keyword": "Given "
});
formatter.match({
  "location": "OrderTShirt.i_am_a_valid_user_and_navigate_to_the_site()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see my store page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_see_my_store_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select sign in to Log in to your my account",
  "keyword": "When "
});
formatter.match({
  "location": "OrderTShirt.i_select_sign_in_to_Log_in_to_your_my_account()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter my login \u003cEmailAddress\u003e and \u003cPassword\u003e to autenticate successfully",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_enter_my_login_and_to_autenticate_successfully(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select my account to view my order history",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_my_account_to_view_my_order_history()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on my account page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_my_account_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select my personal information option",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.i_select_my_personal_information_option()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should be on Your personal information page",
  "keyword": "Then "
});
formatter.match({
  "location": "OrderTShirt.i_should_be_on_Your_personal_information_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "update my \u003cFirstName\u003e details",
  "keyword": "And "
});
formatter.match({
  "location": "OrderTShirt.update_my_details(String)"
});
formatter.result({
  "status": "passed"
});
});